import {Component} from '@angular/core';
import {Router} from "@angular/router";
import {AuthorizationManager} from "../../service/authorizationmanager";
import {DarkModeService} from "../../service/DarkModeService";


@Component({
  selector: 'app-mainwindow',
  templateUrl: './mainwindow.component.html',
  styleUrls: ['./mainwindow.component.css']
})
export class MainwindowComponent {

  opened: boolean = true;

  constructor(private router: Router,public authService: AuthorizationManager,public darkModeSevice:DarkModeService) {
  }

  logout(): void {
    this.router.navigateByUrl("login");
    this.authService.clearUsername();
    this.authService.clearButtonState();
    this.authService.clearMenuState();
    localStorage.removeItem("Authorization");
  }

  AdminmenuItems = this.authService.AdminmenuItems;
  PurchasemenuItems = this.authService.PurchasemenuItems;
  ProductmenuItems = this.authService.ProductmenuItems;
  SalesmenuItems = this.authService.SalesmenuItems;
  ReportsmenuItems = this.authService.ReportsmenuItems;

  isMenuVisible(category: string): boolean {
    switch (category) {
      case 'Admin':
        return this.AdminmenuItems.some(menuItem => menuItem.accessFlag);
      case 'Purchase':
        return this.PurchasemenuItems.some(menuItem => menuItem.accessFlag);
      case 'Product':
        return this.ProductmenuItems.some(menuItem => menuItem.accessFlag);
      case 'Sales':
        return this.SalesmenuItems.some(menuItem => menuItem.accessFlag);
      case 'Reports':
        return this.ReportsmenuItems.some(menuItem => menuItem.accessFlag);
      default:
        return false;
    }
  }
}
