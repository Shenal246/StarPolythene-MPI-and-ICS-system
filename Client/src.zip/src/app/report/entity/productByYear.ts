export class ProductByYear{
  constructor(code: string, percentage: string,quantity:number) {
    this.code = code;
    this.quantity= quantity
    this.percentage = percentage;
  }

  public code! : string;
  public percentage! : string;
  public quantity! : number;

}
