export class Salesdashboard {

  public id !: number;
  public total !: number;

  constructor(id:number,total:number) {
    this.id=id;
    this.total=total;
  }

}
